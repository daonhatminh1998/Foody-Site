import React from "react";

const AdminPage = () => {
  return (
    <div className="container">
      <h1 className="text-center mt-5">Welcome to Admin Site!</h1>
    </div>
  );
};

export default AdminPage;
